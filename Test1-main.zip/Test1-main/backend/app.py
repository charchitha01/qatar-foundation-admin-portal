from flask import Flask, request, jsonify
from flask_cors import CORS
from models import db, Admin, Opportunity

app = Flask(__name__)
CORS(app)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db.init_app(app)


@app.route("/")
def home():
    return "Backend is working"


@app.route("/signup", methods=["POST"])
def signup():
    data = request.json

    full_name = data.get("full_name")
    email = data.get("email")
    password = data.get("password")

    if not full_name or not email or not password:
        return jsonify({"message": "All fields are required"}), 400

    existing_user = Admin.query.filter_by(email=email).first()
    if existing_user:
        return jsonify({"message": "Email already exists"}), 400

    new_admin = Admin(
        full_name=full_name,
        email=email,
        password=password
    )

    db.session.add(new_admin)
    db.session.commit()

    return jsonify({"message": "Signup successful"}), 201
@app.route("/login", methods=["POST"])
def login():
    data = request.json

    email = data.get("email")
    password = data.get("password")

    admin = Admin.query.filter_by(email=email, password=password).first()

    if not admin:
        return jsonify({"message": "Invalid email or password"}), 401

    return jsonify({
        "message": "Login successful",
        "admin_id": admin.id,
        "full_name": admin.full_name
    }), 200

@app.route("/forgot-password", methods=["POST"])
def forgot_password():
    return jsonify({"message": "If this email exists, a reset link has been sent."}), 200

@app.route("/add-opportunity", methods=["POST"])
def add_opportunity():
    data = request.json

    new_opportunity = Opportunity(
        admin_id=1,
        name=data.get("name"),
        duration=data.get("duration"),
        start_date=data.get("start_date"),
        description=data.get("description"),
        skills=data.get("skills"),
        category=data.get("category"),
        future_opportunities=data.get("future_opportunities"),
        max_applicants=data.get("max_applicants")
    )

    db.session.add(new_opportunity)
    db.session.commit()

    return jsonify({"message": "Opportunity added successfully"}), 201


@app.route("/delete-opportunity/<int:id>", methods=["DELETE"])
def delete_opportunity(id):
    opportunity = Opportunity.query.get(id)

    if not opportunity:
        return jsonify({"message": "Opportunity not found"}), 404

    db.session.delete(opportunity)
    db.session.commit()

    return jsonify({"message": "Opportunity deleted successfully"})


@app.route("/get-opportunities", methods=["GET"])
def get_opportunities():
    opportunities = Opportunity.query.all()

    data = []
    for opp in opportunities:
        data.append({
            "id": opp.id,
            "name": opp.name,
            "duration": opp.duration,
            "start_date": opp.start_date,
            "description": opp.description,
            "skills": opp.skills,
            "category": opp.category,
            "future_opportunities": opp.future_opportunities,
            "max_applicants": opp.max_applicants
        })

    return jsonify(data)


with app.app_context():
    db.create_all()


if __name__ == "__main__":
    app.run(debug=True)